const SMOOTH_SCROLL_DURATION = 700;

class Index {
  init() {
    console.log('scroll');
    console.log(SMOOTH_SCROLL_DURATION);
  }
}

export default Index;
