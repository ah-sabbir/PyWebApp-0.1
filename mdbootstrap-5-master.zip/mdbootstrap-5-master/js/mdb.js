/**
 * --------------------------------------------------------------------------
 * MDBootstrap (v5.0.0-alpha): mdb.js
 * Licensed under MIT (https://mdbootstrap.com/license)
 * --------------------------------------------------------------------------
 */

import SmoothScroll from 'src/smooth-scroll';

export {
  SmoothScroll
}
